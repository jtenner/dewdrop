(module
  (@custom "compiler.facts" (before first) "\01\00\01\07dewdrop\050.1.0\00\01\01\01\00\0a\00\01\ff\ff\ff\03\00\00\00\00\00\00\00\00\00\00\01\00\01\00\01\02\01\00\ff\ff\ff\ff\0f\00\00\00\00\00\00\00\01\01\00\00\00\00\01\01\00\00\00\00\00\00\00\00\00\01\00\01\00\01\00\01\02\01\00\ff\ff\ff\ff\0f\00\00\00\00\00\00\01\7f\00\01\00\01\00\01\02\01\00\ff\01\00\01\80\fe\ff\ff\0f\00\00\00\00\00\00\01\01\00\00\00\00\02\01\00\00\00\00\00\00\00\00\00\01\01\01\01\00\00\01\7f\00\01\00\01\00\01\02\01\00\ff\01\00\01\80\fe\ff\ff\0f\00\00\00\00\00\00\01\01\00\00\00\00\03\01\81\80\10\00\00\00\00\00\00\00\00\01\00\01\00\00\01\7f\01\ff\01\01\00\01\00\01\02\01\00\ff\ff\ff\ff\0f\00\00\00\00\00\00\00\01\01\00\00\00\00\04\01\ff\ff\ff\03\00\00\00\00\00\00\00\00\01\01\02\02\00\00\01\7f\01\ff\01\01\01\00\01\02\01\00\ff\ff\ff\ff\0f\00\00\00\00\00\00\01\7f\00\01\00\01\00\01\02\01\00\ff\01\00\01\80\fe\ff\ff\0f\00\00\00\00\00\00\01\01\00\00\00\00\05\01\81\80\10\00\00\00\00\00\00\00\00\01\01\03\01\00\00\01\7f\01\ff\01\01\00\01\00\01\02\01\00\ff\ff\ff\ff\0f\00\00\00\00\00\00\00\01\01\00\00\00\00\06\01\ff\ff\ff\03\00\00\00\00\00\00\00\00\01\01\04\02\00\00\01\7f\01\ff\01\01\01\00\01\02\01\00\ff\ff\ff\ff\0f\00\00\00\00\00\00\01\7f\00\01\00\01\00\01\02\01\00\ff\01\00\01\80\fe\ff\ff\0f\00\00\00\00\00\00\01\01\00\00\00\00\07\01\00\00\00\00\00\00\00\00\00\01\00\00\00\01\01\00\00\00\00\08\01\ff\ff\ff\03\00\00\00\00\00\00\00\00\01\04\00\05\06\07\02\00\01\00\01\02\01\00\ff\ff\ff\ff\0f\00\00\00\00\00\00\01\7f\00\01\00\01\7f\01\ff\01\01\00\01\00\01\02\01\00\ff\ff\ff\ff\0f\00\00\00\00\00\00\00\01\01\00\00\00\00\09\01\ff\ff\ff\03\00\00\00\00\00\00\00\00\01\01\08\00\01\00\01\00\01\02\01\00\ff\ff\ff\ff\0f\00\00\00\00\00\00\00\01\00\00\01\00\00\09\08\01\00\00\01\02\01\00\ff\ff\ff\ff\0f\00\00\00\00\00\00\01\00\00\01\02\01\00\ff\01\00\01\80\fe\ff\ff\0f\00\00\00\00\00\00\09\00\01\00\00\01\02\01\00\ff\01\00\01\80\fe\ff\ff\0f\00\00\00\00\00\00\0e\00\01\00\00\01\02\01\00\ff\ff\ff\ff\0f\00\00\00\00\00\00\00\0f\01\01\00\01\02\01\00\ff\ff\ff\ff\0f\00\00\00\00\00\00\01\00\00\01\02\01\00\ff\01\00\01\80\fe\ff\ff\0f\00\00\00\00\00\00\10\00\01\00\00\01\02\01\00\ff\ff\ff\ff\0f\00\00\00\00\00\00\00\11\01\01\00\01\02\01\00\ff\ff\ff\ff\0f\00\00\00\00\00\00\01\00\00\01\02\01\00\ff\01\00\01\80\fe\ff\ff\0f\00\00\00\00\00\00\12\00\01\00\00\01\02\01\00\ff\ff\ff\ff\0f\00\00\00\00\00\00\00\14\01\00\00\01\02\01\00\ff\ff\ff\ff\0f\00\00\00\00\00\00\01\00\00\01\02\01\00\ff\ff\ff\ff\0f\00\00\00\00\00\00\00\15\00\01\00\00\01\02\01\00\ff\ff\ff\ff\0f\00\00\00\00\00\00\00\00\00\00\01\09\02\09\14\00\00\00\00\00\01\01\01\01\00\00\16\00\01\01\b8\17\01\80\80\80\80\80\f7\02\01\80\80\80\80\80\f7\02\00\01\10\00\09\1c\00\00\00\00\00\01\01\01\01\00\00\18\00\01\01\b8\17\01\80\80\80\80\80\f7\02\01\80\80\80\80\80\f7\02\00\01\10\00\00\00\00\00\02\09\14\00\01\16\00\00\00\01\02\01\01\01\00\00\00\00\01\01\b8\17\01\80\80\80\80\80\f7\02\01\80\80\80\80\80\f7\02\00\01\10\00\09\1c\00\04\18\00\00\00\00\00\01\01\b8\17\01\80\80\80\80\80\f7\02\01\80\80\80\80\80\f7\02\00\01\10\00\00\00\00")
  (type (;0;) (array (mut i32)))
  (type (;1;) (array (mut i64)))
  (type (;2;) (array (mut f32)))
  (type (;3;) (array (mut f64)))
  (type (;4;) (array (mut v128)))
  (type (;5;) (array (mut eqref)))
  (type (;6;) (array (mut i8)))
  (type (;7;) (array (mut i16)))
  (type (;8;) (func (param i32) (result i32)))
  (type (;9;) (func (param i32) (result i32)))
  (type (;10;) (func (param i32) (result i32)))
  (type (;11;) (func (param i32) (result i32)))
  (type (;12;) (func (param v128) (result v128)))
  (type (;13;) (struct (field (ref 4)) (field i32) (field i32)))
  (type (;14;) (func (param eqref) (result i32)))
  (type (;15;) (func (param eqref i32) (result i32)))
  (type (;16;) (func (param eqref) (result i32)))
  (type (;17;) (func (param eqref i32) (result i32)))
  (type (;18;) (func (param i32 i32 i32 i32) (result i32)))
  (type (;19;) (func))
  (type (;20;) (func (param i32 eqref) (result i32)))
  (type (;21;) (func (result i32)))
  (type (;22;) (array (mut v128)))
  (type (;23;) (struct (field (ref 22)) (field i32) (field i32)))
  (type (;24;) (struct (field (ref 22)) (field i32) (field i32)))
  (type (;25;) (struct (field (ref 22)) (field i32) (field i32)))
  (type (;26;) (struct (field (mut (ref 22))) (field (mut i32)) (field (mut i32))))
  (type (;27;) (struct (field (mut (ref 22))) (field (mut i32)) (field (mut i32))))
  (import "wasi_snapshot_preview1" "fd_write" (func (;0;) (type 18) (param i32 i32 i32 i32) (result i32)))
  (memory (;0;) 1)
  (export "main" (func 9))
  (export "memory" (memory 0))
  (func (;1;) (type 8) (param i32) (result i32)
    local.get 0
    i32.const 255
    i32.and
  )
  (func (;2;) (type 9) (param i32) (result i32)
    local.get 0
    call 1
  )
  (func (;3;) (type 14) (param eqref) (result i32)
    local.get 0
    ref.cast (ref 24)
    struct.get 24 2
  )
  (func (;4;) (type 15) (param eqref i32) (result i32)
    (local (ref 13) i32 v128 v128 v128)
    local.get 0
    ref.cast (ref 13)
    ref.cast (ref 13)
    local.set 2
    local.get 1
    local.get 2
    ref.cast (ref 13)
    struct.get 13 2
    i32.ge_u
    if (result i32) ;; label = @1
      i32.const 1
    else
      local.get 1
      i32.const -1
      local.get 2
      ref.cast (ref 13)
      struct.get 13 1
      i32.sub
      i32.gt_u
    end
    if ;; label = @1
      unreachable
    else
    end
    local.get 2
    ref.cast (ref 13)
    struct.get 13 1
    local.get 1
    i32.add
    local.set 3
    local.get 2
    ref.cast (ref 13)
    struct.get 13 0
    ref.cast (ref 4)
    local.get 3
    i32.const 4
    i32.shr_u
    array.get 4
    local.set 4
    local.get 3
    i32.const 15
    i32.and
    call 2
    i8x16.splat
    local.set 5
    local.get 4
    local.set 6
    local.get 6
    local.get 5
    i8x16.swizzle
    i8x16.extract_lane_u 0
  )
  (func (;5;) (type 16) (param eqref) (result i32)
    local.get 0
    call 3
  )
  (func (;6;) (type 17) (param eqref i32) (result i32)
    local.get 0
    local.get 1
    call 4
  )
  (func (;7;) (type 19))
  (func (;8;) (type 20) (param i32 eqref) (result i32)
    (local i32 i32 i32 i32 i32 i32 i32 i32 i32 i32 i32 i32)
    local.get 1
    call 5
    local.set 2
    i32.const 0
    local.set 12
    block ;; label = @1
      loop ;; label = @2
        block ;; label = @3
          i32.const 1
          if ;; label = @4
            local.get 12
            local.set 3
            local.get 3
            local.get 2
            i32.lt_u
            if ;; label = @5
              local.get 2
              local.get 3
              i32.sub
              local.set 4
              local.get 4
              i32.const 65520
              i32.gt_u
              if (result i32) ;; label = @6
                i32.const 65520
              else
                local.get 4
              end
              local.set 5
              i32.const 0
              local.set 10
              block ;; label = @6
                loop ;; label = @7
                  block ;; label = @8
                    i32.const 1
                    if ;; label = @9
                      local.get 10
                      local.set 6
                      local.get 6
                      local.get 5
                      i32.lt_u
                      if ;; label = @10
                        i32.const 16
                        local.get 6
                        i32.add
                        local.get 1
                        local.get 3
                        local.get 6
                        i32.add
                        call 6
                        i32.store8
                        local.get 6
                        i32.const 1
                        i32.add
                        local.set 10
                        br 3 (;@7;)
                        br 2 (;@8;)
                      end
                    end
                    i32.const 1
                    if ;; label = @9
                      call 7
                      br 3 (;@6;)
                      br 1 (;@8;)
                    end
                    unreachable
                  end
                  unreachable
                end
                unreachable
              end
              i32.const 0
              local.set 11
              block ;; label = @6
                loop ;; label = @7
                  block ;; label = @8
                    i32.const 1
                    if ;; label = @9
                      local.get 11
                      local.set 7
                      local.get 7
                      local.get 5
                      i32.lt_u
                      if ;; label = @10
                        local.get 5
                        local.get 7
                        i32.sub
                        local.set 8
                        i32.const 0
                        i32.const 16
                        local.get 7
                        i32.add
                        i32.store
                        i32.const 4
                        local.get 8
                        i32.store
                        i32.const 8
                        i32.const 0
                        i32.store
                        local.get 0
                        i32.const 0
                        i32.const 1
                        i32.const 8
                        call 0
                        i32.const 0
                        i32.ne
                        if ;; label = @11
                          unreachable
                        else
                          i32.const 8
                          i32.load
                          local.set 9
                          local.get 9
                          i32.const 0
                          i32.eq
                          if (result i32) ;; label = @12
                            i32.const 1
                          else
                            local.get 9
                            local.get 8
                            i32.gt_u
                          end
                          if ;; label = @12
                            unreachable
                          else
                            local.get 7
                            local.get 9
                            i32.add
                            local.set 11
                            br 5 (;@7;)
                          end
                          unreachable
                        end
                        unreachable
                        br 2 (;@8;)
                      end
                    end
                    i32.const 1
                    if ;; label = @9
                      call 7
                      br 3 (;@6;)
                      br 1 (;@8;)
                    end
                    unreachable
                  end
                  unreachable
                end
                unreachable
              end
              local.get 3
              local.get 5
              i32.add
              local.set 12
              br 3 (;@2;)
              br 2 (;@3;)
            end
          end
          i32.const 1
          if ;; label = @4
            local.get 2
            local.set 13
            br 3 (;@1;)
            br 1 (;@3;)
          end
          unreachable
        end
        unreachable
      end
      unreachable
    end
    local.get 13
  )
  (func (;9;) (type 21) (result i32)
    i32.const 1
    v128.const i32x4 0x646c6977 0x64726163 0x0000000a 0x00000000
    array.new_fixed 22 1
    i32.const 0
    i32.const 9
    struct.new 24
    call 8
  )
)
